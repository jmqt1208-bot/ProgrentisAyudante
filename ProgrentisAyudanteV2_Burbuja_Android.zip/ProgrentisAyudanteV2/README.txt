AYUDANTE FLOTANTE V2 - ANDROID

Incluye:
- Permiso de superposición para mostrar una burbuja sobre otras apps.
- Captura de pantalla iniciada por el usuario con el diálogo oficial de Android (MediaProjection).
- OCR continuo con ML Kit, limitado aproximadamente a una lectura cada 1,4 segundos.
- Panel flotante que muestra el texto detectado y permite seleccionarlo/copiarlo.
- Notificación persistente para indicar que la captura está activa y permitir detener el servicio.

LÍMITES:
- No inicia sesión en Progrentis ni interactúa con sus controles.
- No pulsa ni envía respuestas automáticamente. La persona revisa el ejercicio y decide qué seleccionar.
- Android muestra un permiso explícito de captura cada vez que se inicia una nueva sesión.
- Esta es una base de proyecto; no se ha compilado ni probado en tu tablet. Puede requerir ajustes según el fabricante y la versión exacta de Android.

CÓMO COMPILAR DESDE LA TABLET:
1. Descarga y descomprime el ZIP.
2. En Chrome entra a https://github.com/ e inicia sesión.
3. Crea un repositorio llamado ProgrentisAyudanteV2.
4. Sube todos los archivos y carpetas del proyecto, incluida .github/workflows.
   Si no aparecen archivos ocultos, activa "mostrar archivos ocultos" en tu administrador de archivos.
5. Confirma los cambios (Commit changes).
6. Abre la pestaña Actions y ejecuta "Compilar APK Android".
7. Cuando la ejecución termine correctamente, descarga el artefacto "Ayudante-flotante-APK".
8. Descomprime el artefacto y abre app-debug.apk para instalarlo.

USO:
1. Abre la app.
2. Pulsa "Activar permiso de burbuja" y concede el permiso en Android.
3. Vuelve a la app y pulsa "Iniciar lectura de pantalla".
4. Acepta el diálogo de Android para compartir pantalla.
5. Cambia a Chrome. La burbuja AI debe quedar visible encima.
6. Toca la burbuja para mostrar u ocultar el texto leído.
7. Para terminar, vuelve a la app y pulsa "Detener asistente".

Si GitHub Actions muestra un error, comparte una captura para corregirlo.
