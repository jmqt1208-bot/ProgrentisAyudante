package com.ayudante.progrentis

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenReaderService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "capture_result_code"
        const val EXTRA_RESULT_DATA = "capture_result_data"
        private const val CHANNEL_ID = "screen_reader"
        private const val NOTIFICATION_ID = 82
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var windowManager: WindowManager? = null
    private var bubble: View? = null
    private var panel: View? = null
    private var panelText: TextView? = null
    private var isPanelOpen = false
    private var lastScan = 0L
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var worker: Handler? = null
    private var workerThread: HandlerThread? = null
    private var screenWidth = 0
    private var screenHeight = 0
    private var density = 1

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, makeNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        workerThread = HandlerThread("screen-ocr").also { it.start() }
        worker = Handler(workerThread!!.looper)
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (code == Activity.RESULT_OK && data != null && projection == null) {
            try {
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = manager.getMediaProjection(code, data)
                startCapture()
            } catch (_: Exception) {
                updatePanel("No se pudo iniciar la captura. Detén el asistente e inténtalo otra vez.")
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        density = metrics.densityDpi
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = SystemClock.elapsedRealtime()
            if (now - lastScan < 1400) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastScan = now
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            runOcr(image)
        }, worker)
        virtualDisplay = projection?.createVirtualDisplay(
            "ProgrentisScreenReader",
            screenWidth, screenHeight, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, worker
        )
        updatePanel("Escaneando la pantalla. Toca la burbuja para ver el texto reconocido.")
    }

    private fun runOcr(mediaImage: Image) {
        try {
            val bitmap = imageToBitmap(mediaImage)
            mediaImage.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { vision ->
                    val extracted = vision.text.trim()
                    if (extracted.isNotEmpty()) {
                        updatePanel(extracted.take(5000))
                    }
                }
                .addOnFailureListener {
                    updatePanel("No pude leer esta imagen. Prueba con texto más grande o una pantalla menos borrosa.")
                }
        } catch (_: Exception) {
            try { mediaImage.close() } catch (_: Exception) {}
        }
    }

    private fun imageToBitmap(image: Image): android.graphics.Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = android.graphics.Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height,
            android.graphics.Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        val cropped = android.graphics.Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun showBubble() {
        val wm = windowManager ?: return
        val bubbleView = Button(this).apply {
            text = "AI"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF3157D5.toInt()))
            setOnClickListener { togglePanel() }
            setOnTouchListener(object : View.OnTouchListener {
                var startX = 0
                var startY = 0
                var touchX = 0f
                var touchY = 0f
                var moved = false
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = lp.x; startY = lp.y
                            touchX = event.rawX; touchY = event.rawY; moved = false
                            return false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (event.rawX - touchX).toInt()
                            val dy = (event.rawY - touchY).toInt()
                            if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                            if (moved) {
                                lp.x = startX + dx; lp.y = startY + dy
                                wm.updateViewLayout(v, lp)
                            }
                            return moved
                        }
                        MotionEvent.ACTION_UP -> return moved
                    }
                    return false
                }
            })
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(54), dp(54), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(14); y = dp(180) }
        try {
            wm.addView(bubbleView, params)
            bubble = bubbleView
        } catch (_: Exception) {}
    }

    private fun togglePanel() {
        if (isPanelOpen) {
            try { windowManager?.removeView(panel) } catch (_: Exception) {}
            panel = null
            isPanelOpen = false
            return
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFF8FAFC.toInt())
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply {
            text = "Texto detectado"
            textSize = 17f
            setTextColor(0xFF172554.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply {
            text = "Cerrar"
            setOnClickListener { togglePanel() }
        })
        panelText = TextView(this).apply {
            text = "Esperando texto de la pantalla…"
            textSize = 15f
            setTextColor(0xFF0F172A.toInt())
            setTextIsSelectable(true)
            setPadding(0, dp(8), 0, dp(8))
        }
        val scroll = ScrollView(this).apply {
            addView(panelText)
            layoutParams = LinearLayout.LayoutParams(-1, dp(260))
        }
        container.addView(header)
        container.addView(scroll)
        container.addView(TextView(this).apply {
            text = "La app solo lee y muestra el contenido. Tú decides qué respuesta seleccionar."
            textSize = 12f
            setTextColor(0xFF64748B.toInt())
        })
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(300), -2, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(245) }
        try {
            windowManager?.addView(container, params)
            panel = container
            isPanelOpen = true
        } catch (_: Exception) {}
    }

    private fun updatePanel(text: String) {
        runOnUiThread { panelText?.text = text }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Lectura de pantalla",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun makeNotification(): Notification {
        val stop = Intent(this, StopReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 0, stop,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Ayudante flotante activo")
            .setContentText("La captura de pantalla está activa. Toca para detener desde la app.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(0, "Detener", pending)
            .build()
    }

    override fun onDestroy() {
        try { windowManager?.removeView(bubble) } catch (_: Exception) {}
        try { if (isPanelOpen) windowManager?.removeView(panel) } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        recognizer.close()
        workerThread?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
