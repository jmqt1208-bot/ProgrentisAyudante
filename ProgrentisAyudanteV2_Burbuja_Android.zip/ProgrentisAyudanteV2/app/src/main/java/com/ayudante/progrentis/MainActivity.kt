package com.ayudante.progrentis

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureRequest = 7001
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFFF5F7FC.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Ayudante flotante"
            textSize = 27f
            setTextColor(0xFF172554.toInt())
            setPadding(0, 0, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = "Permite mostrar una burbuja encima de Chrome y leer el texto visible de la pantalla mientras la captura esté activa. Android siempre te pedirá autorización para compartir la pantalla."
            textSize = 16f
            setTextColor(0xFF334155.toInt())
            setPadding(0, 0, 0, pad)
        })
        val overlayButton = Button(this).apply {
            text = "1. Activar permiso de burbuja"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else status.text = "Permiso de burbuja concedido."
            }
        }
        val startButton = Button(this).apply {
            text = "2. Iniciar lectura de pantalla"
            setOnClickListener { requestScreenCapture() }
        }
        val stopButton = Button(this).apply {
            text = "Detener asistente"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenReaderService::class.java))
                status.text = "Asistente detenido."
            }
        }
        status = TextView(this).apply {
            text = "Primero activa el permiso de burbuja."
            textSize = 14f
            setTextColor(0xFF475569.toInt())
            setPadding(0, pad, 0, 0)
        }
        root.addView(overlayButton)
        root.addView(startButton)
        root.addView(stopButton)
        root.addView(status)
        setContentView(root)
    }

    private fun requestScreenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Activa primero el permiso de burbuja."
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenReaderService::class.java).apply {
                putExtra(ScreenReaderService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenReaderService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
            status.text = "Lectura activa. Cambia a Chrome y usa la burbuja."
        } else {
            status.text = "No se autorizó la captura de pantalla."
        }
    }
}
